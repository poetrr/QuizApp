FastAPI based backend for AutoForms
Refer [Setup Instructions](https://github.com/AnushM55/autoquiz_setup)
