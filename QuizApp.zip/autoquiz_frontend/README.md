REACT based frontend for the autoquiz app. 

Refer [Setup instructions](https://github.com/AnushM55/autoquiz_setup)
